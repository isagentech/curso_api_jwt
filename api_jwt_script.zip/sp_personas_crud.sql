call sp_personas_crud (1);

create procedure sp_personas_crud (
	opcion_ int
	
)


begin

			declare exit HANDLER for SQLEXCEPTION
			begin
			   
				 get diagnostics CONDITION 1 @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
				 select @p1 as CodigoError , @p2 as MensajeError;
			
			end;
			
			
			if opcion_ =  1 then
				 
				 select '0000' as CodigoError, 'TransaacionOK' as MensajeError;
				 
				select 
					a.IdPersona,
					a.TipoIdentificacion,
					a.Identificacion,
					a.Sexo,
					a.Nombres,
					a.Apellidos,
					DATE_FORMAT(a.FechaNacimiento, "%Y-%m-%d") as FechaNacimiento,
					a.TelefonoConvencional,
					a.TelefonoCelular,
					a.Correo,
					a.Direccion,
					a.PathImagen,
					a.Estado as EstadoPersona,
					b.IdRol,
					r.Rol,
					b.IdUsuario,
					b.Usuario,
					b.Estado as EstadoUsuario
					from tbl_personas a inner join tbl_usuarios b on a.IdPersona = b.IdPersona
					inner join tbl_roles r on r.IdRol = b.IdRol
					where 
					a.Estado <> 'E' ;
			
			
			end if;





end;