/*
		1.- Roles de usuario
		2.- Personas
		3.- Usuarios 
*/

create table tbl_roles(
	IdRol int PRIMARY key  AUTO_INCREMENT,
	Rol varchar(50),
	Estado char(1),
	UsuarioCrea varchar(50),
	FechaCrea datetime,	
	FechaModifica datetime,
	UsuarioModifica varchar(50),
	UsuarioElimina varchar(50),
	FechaElimina datetime
);

/*alter table tbl_roles add CONSTRAINT  pk_IdRol_Rol PRIMARY key (IdRol) ;*/

create table tbl_personas(
	IdPersona int PRIMARY KEY AUTO_INCREMENT,
	TipoIdentificacion varchar(3),
	Identificacion varchar(13),
	Nombres varchar(100),
	Apellidos varchar(100),
	FechaNacimiento date,
	TelefonoConvencional varchar(10),
	TelefonoCelular varchar(10),
	Correo varchar(150),
	Direccion varchar(200),
	PathImagen text,
	Estado char(1),
	Sexo char(1),
	UsuarioCrea varchar(50),
	FechaCrea datetime,	
	FechaModifica datetime,
	UsuarioModifica varchar(50),
	UsuarioElimina varchar(50),
	FechaElimina datetime
);

/*alter table tbl_persona add CONSTRAINT  pk_IdPersona_Persona PRIMARY key (IdPersona) ;*/

create table tbl_usuarios(
   IdUsuario int PRIMARY KEY AUTO_INCREMENT,
	 IdRol int,
	 IdPersona int,
	 Usuario varchar(50),
	 Clave text,
	 ClaveTemp text,
	 Estado char(1),
	 UsuarioCrea varchar(50),
	 FechaCrea datetime,	
	 FechaModifica datetime,
	 UsuarioModifica varchar(50),
	 UsuarioElimina varchar(50),
	 FechaElimina datetime
);

/*alter table tbl_usuarios add constraint pK_IdUsuario_Usuario PRIMARY key (IdUsuario);*/





