call sp_autenticacion_crud(1,null,'admin',null,null);

create procedure sp_autenticacion_crud (
	opcion_ int,
	IdUsuario_ int,
	Usuario_ varchar(50), 
	Correo_ varchar(150),
	Clave_ text
)


begin

			declare exit HANDLER for SQLEXCEPTION
			begin
			   
				 get diagnostics CONDITION 1 @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
				 select @p1 as CodigoError , @p2 as MensajeError;
			
			end;
			
			
			if opcion_ =  1 then
				 
				 select '0000' as CodigoError, 'TransaacionOK' as MensajeError;
				 
				 select 
					per.IdPersona, 
					usr.IdUsuario, 
					usr.Usuario,	
					rol.IdRol,
					rol.Rol,
					usr.Estado as Estado,
					usr.Clave,
					usr.ClaveTemp
				from tbl_personas per inner join tbl_usuarios usr on per.IdPersona = usr.IdPersona
				inner join tbl_roles rol on rol.IdRol = usr.IdRol 
				where 				 
					per.Estado = 'A' and
					rol.Estado = 'A' and 
		      usr.Usuario = Usuario_ ;
			
			
			end if;







end;